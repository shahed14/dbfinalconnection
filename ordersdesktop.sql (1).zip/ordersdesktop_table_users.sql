
-- --------------------------------------------------------

--
-- بنية الجدول "users"
--

CREATE TABLE "users" ;

--
-- RELATIONSHIPS FOR TABLE `users`:
--

--
-- إرجاع أو استيراد بيانات الجدول "users"
--

SET IDENTITY_INSERT "users" ON ;
INSERT INTO "users" ("Id", "Name", "Email", "Mobile", "Password", "Role") VALUES
(2, 'shahed', 'shahed@gmail.com', '0595966272', '123456789', 'Admin'),
(4, 'Aya', 'aya@gmail.com', '0569483285', 'Aya111111', 'client'),
(8, 'Anwar', 'Anwar@gmail.com', '05994704009', 'amar444', 'Client');

SET IDENTITY_INSERT "users" OFF;
