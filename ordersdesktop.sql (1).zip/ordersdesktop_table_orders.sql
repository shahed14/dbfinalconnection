
-- --------------------------------------------------------

--
-- بنية الجدول "orders"
--

CREATE TABLE "orders" ;

--
-- RELATIONSHIPS FOR TABLE `orders`:
--

--
-- إرجاع أو استيراد بيانات الجدول "orders"
--

SET IDENTITY_INSERT "orders" ON ;
INSERT INTO "orders" ("Id", "Name", "User_id", "Quantity", "Date", "Product_id") VALUES
(1117, 'cups', 2, 3, '3/6', 40),
(1118, 'table', 4, 1, '3/7', 42),
(1121, 'computer', 1, 1, '1/6', 39),
(1128, 'cups', 8, 1, '8/8', 42),
(1129, 'computer', 1, 3, '3/4', 39);

SET IDENTITY_INSERT "orders" OFF;
