
-- --------------------------------------------------------

--
-- بنية الجدول "products"
--

CREATE TABLE "products" ;

--
-- RELATIONSHIPS FOR TABLE `products`:
--

--
-- إرجاع أو استيراد بيانات الجدول "products"
--

SET IDENTITY_INSERT "products" ON ;
INSERT INTO "products" ("Id", "Name", "Category", "Price", "Quantity", "Description") VALUES
(39, 'computer', 'electical', 1000, 1, 'lenovo i5'),
(40, 'table', 'wood', 50, 1, 'wood table'),
(41, 'mobile', 'electical', 2, 800, 'xiomi poco3'),
(42, 'cup', 'home equipment', 5, 20, 'xiomi poco3');

SET IDENTITY_INSERT "products" OFF;
