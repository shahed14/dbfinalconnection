
-- --------------------------------------------------------

--
-- بنية الجدول "invoices"
--

CREATE TABLE "invoices" ;

--
-- RELATIONSHIPS FOR TABLE `invoices`:
--

--
-- إرجاع أو استيراد بيانات الجدول "invoices"
--

SET IDENTITY_INSERT "invoices" ON ;
INSERT INTO "invoices" ("Id", "Order_id", "Total_price", "Date") VALUES
(333, 1118, 2000, '5/7'),
(444, 1121, 900, '6/8'),
(555, 1117, 15, '7/9');

SET IDENTITY_INSERT "invoices" OFF;
